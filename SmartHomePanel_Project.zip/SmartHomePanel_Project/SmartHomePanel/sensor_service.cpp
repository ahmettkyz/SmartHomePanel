#include "sensor_service.h"

// ============================================================
// SENSOR SECIMI: kullandigin sensore gore SADECE BIRINI ac
// ============================================================
#define SENSOR_LM35         // analog, 10 mV/°C, 0°C'de 0 mV
//#define SENSOR_TMP36      // analog, 10 mV/°C, 0°C'de 500 mV
//#define SENSOR_NTC10K     // 10k NTC termistor + 10k bolucu direnc
//#define SENSOR_SIMULATED  // sensor yokken test icin

// Waveshare ESP32-S3 Touch LCD 7: Sensor AD konektoru GPIO6'ya bagli
#define SENSOR_AD_PIN   6

static const unsigned long READ_INTERVAL_MS = 2000;
static const int SAMPLE_COUNT = 16;          // gurultuyu azaltmak icin ortalama

static unsigned long last_read = 0;
static float s_temp = NAN;
static bool  s_ok   = false;
static bool  s_first = true;

// NTC parametreleri (10k, B=3950, 25°C referans)
#ifdef SENSOR_NTC10K
static const float NTC_R_FIXED  = 10000.0f;   // bolucu direnc
static const float NTC_R_NOM    = 10000.0f;   // 25°C'deki direnc
static const float NTC_T_NOM    = 298.15f;    // 25°C, Kelvin
static const float NTC_B        = 3950.0f;
static const float NTC_VCC_MV   = 3300.0f;
#endif

// ADC'yi birden fazla okuyup ortalama al
static float read_millivolts() {
    long sum = 0;
    for (int i = 0; i < SAMPLE_COUNT; i++) {
        sum += analogReadMilliVolts(SENSOR_AD_PIN);
        delayMicroseconds(200);
    }
    return (float)sum / SAMPLE_COUNT;
}

void sensor_begin() {
#ifdef SENSOR_SIMULATED
    Serial.println("[SENS] Simulasyon modu");
    s_temp = 21.0f;
    s_ok = true;
    return;
#else
    pinMode(SENSOR_AD_PIN, INPUT);
    analogReadResolution(12);                  // 0-4095
    analogSetPinAttenuation(SENSOR_AD_PIN, ADC_11db);  // ~0-3.1V araligi
    Serial.printf("[SENS] Analog sensor hazir, pin GPIO%d\n", SENSOR_AD_PIN);
#endif

    last_read = millis() - READ_INTERVAL_MS;   // ilk okumayi hemen yap
    sensor_tick();
}

void sensor_tick() {
#ifdef SENSOR_SIMULATED
    s_ok = true;
    return;
#else
    unsigned long now = millis();
    if (now - last_read < READ_INTERVAL_MS) return;
    last_read = now;

    float mv = read_millivolts();
    float t  = NAN;

  #if defined(SENSOR_LM35)
    // LM35: 10 mV/°C, offset yok
    t = mv / 10.0f;
    if (mv < 5.0f || mv > 1500.0f) t = NAN;    // makul aralik disi -> hatali

  #elif defined(SENSOR_TMP36)
    // TMP36: 10 mV/°C, 500 mV offset (0°C = 500 mV)
    t = (mv - 500.0f) / 10.0f;
    if (mv < 100.0f || mv > 2000.0f) t = NAN;

  #elif defined(SENSOR_NTC10K)
    // Gerilim boluculu NTC: Vout = Vcc * Rntc / (Rfixed + Rntc)
    if (mv > 10.0f && mv < NTC_VCC_MV - 10.0f) {
        float r_ntc = NTC_R_FIXED * mv / (NTC_VCC_MV - mv);
        float steinhart = logf(r_ntc / NTC_R_NOM) / NTC_B + 1.0f / NTC_T_NOM;
        t = (1.0f / steinhart) - 273.15f;
    }
  #endif

    if (isnan(t) || t < -40.0f || t > 100.0f) {
        s_ok = false;
        Serial.printf("[SENS] Gecersiz okuma: %.0f mV\n", mv);
        return;
    }

    // Yumusatma: ani sicramalari azalt
    if (s_first) { s_temp = t; s_first = false; }
    else         { s_temp = s_temp * 0.8f + t * 0.2f; }

    s_ok = true;
#endif
}

float sensor_get_temperature() {
    return s_ok ? s_temp : NAN;
}

bool sensor_is_ok() {
    return s_ok;
}