#include "weather_service.h"
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>

WeatherData currentWeatherData;

static const char* WEATHER_URL =
    "https://api.open-meteo.com/v1/forecast?latitude=40.7569&longitude=30.3783&current=temperature_2m,weather_code&daily=weather_code,temperature_2m_max,temperature_2m_min&timezone=Europe%2FIstanbul&forecast_days=7";

static const unsigned long UPDATE_INTERVAL_MS = 15UL * 60UL * 1000UL; // 15 min
static unsigned long lastSuccessMs = 0;
static unsigned long lastTryMs     = 0;
static bool          firstRun      = true;

static const char* DAY_NAMES[7] =
    {"Pazar", "Pazartesi", "Sali", "Carsamba", "Persembe", "Cuma", "Cumartesi"};


static int dayOfWeekFromDate(int y, int m, int d) {
    static const int t[] = {0, 3, 2, 5, 0, 3, 5, 1, 4, 6, 2, 4};
    if (m < 3) y -= 1;
    int w = (y + y / 4 - y / 100 + y / 400 + t[m - 1] + d) % 7;
    return (w < 0) ? w + 7 : w;
}

static const char* dayNameFromISO(const char* iso) {
    if (iso == nullptr) return "---";
    int y = 0, m = 0, d = 0;
    if (sscanf(iso, "%4d-%2d-%2d", &y, &m, &d) != 3) return "---";
    if (m < 1 || m > 12 || d < 1 || d > 31) return "---";
    return DAY_NAMES[dayOfWeekFromDate(y, m, d)];
}

static const char* wmoToText(int code) {
    if (code == 0)                      return "Gunesli";
    if (code >= 1  && code <= 3)      return "Parcali Bulutlu";
    if (code == 45 || code == 48)     return "Sisli";
    if (code >= 51 && code <= 67)     return "Yagmurlu";
    if (code >= 71 && code <= 77)     return "Karli";
    if (code >= 80 && code <= 82)     return "Saganak";
    if (code >= 85 && code <= 86)     return "Kar Saganagi";
    if (code >= 95)                     return "Gok Gurultulu";
    return "Bulutlu";
}

static int wmoToIcon(int code) {
    if (code == 0) return 0;
    if (code >= 51) return 1;
    return 2;
}

// API

void weather_service_begin() {
    currentWeatherData.temperature = 0.0f;
    currentWeatherData.description = "Yukleniyor...";
    for (int i = 0; i < 5; i++) {
        currentWeatherData.forecast[i].dayName      = "---";
        currentWeatherData.forecast[i].tempMax      = 0.0f;
        currentWeatherData.forecast[i].tempMin      = 0.0f;
        currentWeatherData.forecast[i].weatherCode = 0;
    }
    Serial.println("Canli hava durumu servisi baslatildi.");
}

bool weather_update() {
    lastTryMs = millis();
    firstRun  = false;

    if (WiFi.status() != WL_CONNECTED) {
        Serial.println("Wi-Fi bagli degil, canli hava durumu alinamiyor!");
        currentWeatherData.description = "Baglanti Yok";
        return false;
    }

    WiFiClientSecure client;
    client.setInsecure(); 

    HTTPClient http;
    http.setConnectTimeout(10000);
    http.setTimeout(10000);
    http.setFollowRedirects(HTTPC_STRICT_FOLLOW_REDIRECTS);
    http.useHTTP10(true);

    if (!http.begin(client, WEATHER_URL)) {
        Serial.println("HTTP begin basarisiz!");
        currentWeatherData.description = "Baglanti Hatasi";
        return false;
    }

    int httpCode = http.GET();
    if (httpCode != HTTP_CODE_OK) {
        Serial.printf("HTTP Istek Basarisiz, Kod: %d\n", httpCode);
        http.end();
        currentWeatherData.description = "Servis Hatasi";
        return false;
    }

#if ARDUINOJSON_VERSION_MAJOR >= 7
    JsonDocument filter;
    JsonDocument doc;
#else
    DynamicJsonDocument filter(512);
    DynamicJsonDocument doc(4096);
#endif

    filter["current"]["temperature_2m"]     = true;
    filter["current"]["weather_code"]       = true;
    filter["daily"]["time"]                 = true;
    filter["daily"]["weather_code"]         = true;
    filter["daily"]["temperature_2m_max"]   = true;
    filter["daily"]["temperature_2m_min"]   = true;

    DeserializationError error = deserializeJson(
        doc, http.getStream(), DeserializationOption::Filter(filter));

    http.end();

    if (error) {
        Serial.print("JSON Parse Hatasi: ");
        Serial.println(error.c_str());
        currentWeatherData.description = "Veri Hatasi";
        return false;
    }

    if (!doc["current"]["temperature_2m"].isNull()) {
        currentWeatherData.temperature = doc["current"]["temperature_2m"].as<float>();
    }
    int currentCode = doc["current"]["weather_code"] | 0;
    currentWeatherData.description = wmoToText(currentCode);

    JsonArray days     = doc["daily"]["time"];
    JsonArray dailyMax = doc["daily"]["temperature_2m_max"];
    JsonArray dailyMin = doc["daily"]["temperature_2m_min"];
    JsonArray codes    = doc["daily"]["weather_code"];

    if (days.isNull() || days.size() < 6) {
        Serial.println("Gunluk tahmin verisi eksik geldi.");
        return false;
    }

    for (int i = 0; i < 5; i++) {
        int idx = i + 1; 
        
        const char* isoDate = days[idx].as<const char*>();
        currentWeatherData.forecast[i].dayName = dayNameFromISO(isoDate);

        if (!dailyMax[idx].isNull()) currentWeatherData.forecast[i].tempMax = dailyMax[idx].as<float>();
        if (!dailyMin[idx].isNull()) currentWeatherData.forecast[i].tempMin = dailyMin[idx].as<float>();

        int code = codes[idx] | 0;
        currentWeatherData.forecast[i].weatherCode = wmoToIcon(code);
    }

    lastSuccessMs = millis();
    Serial.printf("Canli hava durumu guncellendi: %.1f C\n", currentWeatherData.temperature);
    return true;
}

void weather_tick() {
    if (firstRun) {
        if (WiFi.status() == WL_CONNECTED) {
            weather_update();
        }
        return;
    }
    unsigned long now = millis();
    unsigned long wait = (lastSuccessMs == 0) ? 30000UL : UPDATE_INTERVAL_MS;
    if (now - lastTryMs >= wait) {
        weather_update();
    }
}

WeatherData weather_get() {
    return currentWeatherData;
}