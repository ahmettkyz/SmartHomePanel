#include "wifi_service.h"
#include <WiFi.h>

static bool wifi_power_enabled = true;
static int scanned_network_count = 0;

void wifi_service_begin() {
    WiFi.mode(WIFI_STA);
    wifi_power_enabled = true;
    Serial.println("Wi-Fi servisi baslatildi, varsayilan: ACIK");
    // WiFi.begin() cagrilmiyor: baglanti isini wifi_manager yapiyor
}

void wifi_set_power(bool enable) {
    wifi_power_enabled = enable;
    if (enable) {
        WiFi.mode(WIFI_STA);
        delay(100);                  // surucunun hazir olmasi icin
        Serial.println("Wi-Fi Acildi.");
        // WiFi.begin() yok: baglantiyi wifi_manager yonetiyor
    } else {
        WiFi.disconnect(false, false);   // kayitlara DOKUNMA
        WiFi.mode(WIFI_OFF);
        scanned_network_count = 0;
        Serial.println("Wi-Fi Kapatildi.");
    }
}

bool wifi_get_power() {
    return wifi_power_enabled;
}

void wifi_scan_networks() {
    if (!wifi_power_enabled) {
        scanned_network_count = 0;
        return;
    }
    Serial.println("Aglar taraniyor...");
    scanned_network_count = WiFi.scanNetworks();
    Serial.printf("Bulunan ag sayisi: %d\n", scanned_network_count);
}

int wifi_get_network_count() {
    if (!wifi_power_enabled) return 0;
    return scanned_network_count;
}

String wifi_get_ssid(int index) {
    if (index >= 0 && index < scanned_network_count) {
        return WiFi.SSID(index);
    }
    return "";
}

void wifi_connect_to(const char* ssid, const char* password) {
    if (!wifi_power_enabled) return;
    Serial.printf("Baglaniliyor: %s\n", ssid);
    WiFi.begin(ssid, password);
}