#include <Arduino.h>
#include <esp_display_panel.hpp>
#include <lvgl.h>
#include "lvgl_v8_port.h"
#include "ui.h"
#include "wifi_manager.h"
#include "time_service.h"
#include "weather_service.h"
#include "sensor_service.h"
#include "ui_events.h"

extern void current_time(lv_event_t * e);
extern void current_weather(lv_event_t * e);
extern void update_thermostat_ui();

extern void open_general_settings(lv_event_t * e);
extern void open_wifi_settings(lv_event_t * e);
extern void open_sensitivity_settings(lv_event_t * e);
extern void open_time_settings(lv_event_t * e);
extern void return_to_main_screen(lv_event_t * e);
extern void wifi_power_toggle(lv_event_t * e);
extern void event_sensitivity_changed(lv_event_t * e);
extern void thememode(lv_event_t * e);
extern void calendar_event_cb(lv_event_t * e);

unsigned long lastTimeUpdate = 0;
unsigned long lastWeatherUpdate = 0;

#define TIME_UPDATE_MS       1000UL       //1 min
#define WEATHER_UPDATE_MS    300000UL     //5 min

using namespace esp_panel::board;
using namespace esp_panel::drivers;

Board *board;

void setup()
{
    Serial.begin(115200);
    board = new Board();
    board->init();
    auto lcd = board->getLCD();
    lcd->configFrameBufferNumber(
            LVGL_PORT_DISP_BUFFER_NUM);

    auto lcd_bus = lcd->getBus();

   if(lcd_bus->getBasicAttributes().type == ESP_PANEL_BUS_TYPE_RGB)
    {
        // Important for drift the screen issue
        static_cast<BusRGB*>(lcd_bus)->configRGB_BounceBufferSize(lcd->getFrameWidth() * 30);
    }

    board->begin();
    lvgl_port_init(
            board->getLCD(),
            board->getTouch());
    wifi_begin();
    time_begin();
    sensor_begin();  
    weather_update();

    lvgl_port_lock(-1);
    ui_init();

    // Footer Panel Screens
    lv_obj_add_event_cb(ui_Button_General, open_general_settings, LV_EVENT_CLICKED, NULL);
    lv_obj_add_event_cb(ui_Button_Wifi, open_wifi_settings, LV_EVENT_CLICKED, NULL);
    lv_obj_add_event_cb(ui_Button_Sens, open_sensitivity_settings, LV_EVENT_CLICKED, NULL);
    lv_obj_add_event_cb(ui_Button_Time, open_time_settings, LV_EVENT_CLICKED, NULL);

    // Subscreens to main screen
    lv_obj_add_event_cb(ui_Button_Back_General, return_to_main_screen, LV_EVENT_CLICKED, NULL);
    lv_obj_add_event_cb(ui_Button_Back_Wifi, return_to_main_screen, LV_EVENT_CLICKED, NULL);
    lv_obj_add_event_cb(ui_Button_Back_Sens, return_to_main_screen, LV_EVENT_CLICKED, NULL);
    lv_obj_add_event_cb(ui_Button_Back_Time, return_to_main_screen, LV_EVENT_CLICKED, NULL);

    // Events
    lv_obj_add_event_cb(ui_Switch1, thememode, LV_EVENT_VALUE_CHANGED, NULL);
    lv_obj_add_event_cb(ui_Switch_WifiPower, wifi_power_toggle, LV_EVENT_VALUE_CHANGED, NULL);
    lv_obj_add_event_cb(ui_Dropdown_Sensitivity, event_sensitivity_changed, LV_EVENT_VALUE_CHANGED, NULL);
    lv_obj_add_event_cb(ui_Calendar, calendar_event_cb, LV_EVENT_VALUE_CHANGED, NULL);
    
    current_time(NULL);
    current_weather(NULL);
    update_thermostat_ui();

    lvgl_port_unlock();
}

void loop()
{
    time_tick(); 
    sensor_tick();
    handle_wifi();
    unsigned long now = millis();

    /*
        Time UI Update Routine
    */
    if(now - lastTimeUpdate > TIME_UPDATE_MS)
    {
        lastTimeUpdate = now;

        if (lvgl_port_lock(0)) {
            current_time(NULL);
            update_thermostat_ui();
            lvgl_port_unlock();
        }
    }

    /*
        Weather API and UI Update Routine
    */
    if(now - lastWeatherUpdate > WEATHER_UPDATE_MS)
    {
        lastWeatherUpdate = now;

        if(wifi_connected())
        {
            bool success = weather_update();

            if(success)
            {
                if (lvgl_port_lock(0)) {
                    current_weather(NULL);
                    lvgl_port_unlock();
                }
            }
        }
    }
    // Slight delay to prevent Watchdog Timer (WDT) reset
    delay(5);
    vTaskDelay(pdMS_TO_TICKS(10)); 
}