#pragma once
#include <Arduino.h>

void   wifi_begin();
void   handle_wifi();
bool   wifi_connected();
void   wifi_connect(const char* ssid, const char* pass);
void   wifi_forget();
String wifi_ssid();