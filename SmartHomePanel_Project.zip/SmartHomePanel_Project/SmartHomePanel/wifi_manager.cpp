#include "wifi_manager.h"
#include <WiFi.h>
#include <Preferences.h>

static Preferences prefs;
static String s_ssid, s_pass;
static bool   s_saved = false;

void wifi_begin() {
    WiFi.mode(WIFI_STA);
    WiFi.setAutoReconnect(true);

    prefs.begin("wm_cfg", false);
    s_ssid = prefs.getString("ssid", "");
    s_pass = prefs.getString("pass", "");
    prefs.end();

    if (s_ssid.length() && s_pass.length() == 0) {
        Serial.println("[WM] Bozuk kayit (sifre bos), siliniyor");
        prefs.begin("wm_cfg", false);
        prefs.clear();
        prefs.end();
        s_ssid = "";
    }

    if (s_ssid.length()) {
        Serial.printf("[WM] Kayitli ag: %s (sifre uzunluk %u)\n",
                      s_ssid.c_str(), (unsigned)s_pass.length());
        WiFi.begin(s_ssid.c_str(), s_pass.c_str());
        s_saved = true;
    } else {
        Serial.println("[WM] Kayitli ag yok");
    }
}

void wifi_connect(const char* ssid, const char* pass) {
    s_ssid = ssid;
    s_pass = (pass ? pass : "");
    s_saved = false;

    WiFi.disconnect(false, false);
    WiFi.begin(s_ssid.c_str(), s_pass.c_str());
    Serial.printf("[WM] Baglaniliyor: %s\n", s_ssid.c_str());
}

void handle_wifi() {
    if (!s_saved && WiFi.status() == WL_CONNECTED) {
        s_saved = true;
        prefs.begin("wm_cfg", false);
        prefs.putString("ssid", s_ssid);
        prefs.putString("pass", s_pass);
        prefs.end();
        Serial.printf("[WM] Kaydedildi: %s (sifre uzunluk %u)\n",
                      s_ssid.c_str(), (unsigned)s_pass.length());
    }
}

bool wifi_connected() {
    return WiFi.status() == WL_CONNECTED;
}

void wifi_forget() {
    prefs.begin("wm_cfg", false);
    prefs.clear();
    prefs.end();

    WiFi.disconnect(false, false);
    WiFi.mode(WIFI_STA);

    s_ssid = ""; s_pass = ""; s_saved = false;
    Serial.println("[WM] Unutuldu");
}

String wifi_ssid() {
    return WiFi.status() == WL_CONNECTED ? WiFi.SSID() : s_ssid;
}