#ifndef TIME_SERVICE_H
#define TIME_SERVICE_H

#include <Arduino.h>
#include <string>

struct TimeData {
    std::string fullTime;   
    std::string day;        
    std::string date;       
};

void     time_begin();          // Upload again to clock from NVS + Ready to NVS
TimeData time_get_data();       // Display data
void     time_tick();           // in loop()
void     time_save_now();       // Write to NVS that current time 
void     time_set_manual(int h, int mi, int d, int mo, int y);   // Save button

#endif