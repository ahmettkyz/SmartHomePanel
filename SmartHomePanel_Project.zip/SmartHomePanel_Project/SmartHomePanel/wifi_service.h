#ifndef WIFI_SERVICE_H
#define WIFI_SERVICE_H

#include <Arduino.h>

void wifi_service_begin();
void wifi_scan_networks();
void wifi_set_power(bool enable);
bool wifi_get_power();
void wifi_connect_to(const char* ssid, const char* password);
int wifi_get_network_count();
String wifi_get_ssid(int index);

#endif