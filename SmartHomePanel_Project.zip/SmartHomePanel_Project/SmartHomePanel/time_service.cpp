#include "time_service.h"
#include <WiFi.h>
#include <Preferences.h>
#include <time.h>

int current_hour = 12;
int current_minute = 0;
int current_second = 0;
int current_day = 1;
int current_month = 1;
int current_year = 2026;

static Preferences clkPrefs;
static unsigned long tick_last = 0;
static unsigned long save_last = 0;
static unsigned long ntp_last  = 0;
static bool ntp_configured = false;

static const unsigned long SAVE_INTERVAL_MS = 300000UL;    // 5 min
static const unsigned long NTP_INTERVAL_MS  = 10000UL;   // 30 min
static const long GMT_OFFSET_SEC = 3 * 3600;               // UTC+3

static int days_in_month(int m, int y) {
    if (m == 2) return ((y % 4 == 0 && y % 100 != 0) || (y % 400 == 0)) ? 29 : 28;
    if (m == 4 || m == 6 || m == 9 || m == 11) return 30;
    return 31;
}

static int weekday_index(int d, int m, int y) {
    if (m < 3) { m += 12; y -= 1; }
    int k = y % 100, j = y / 100;
    int h = (d + (13 * (m + 1)) / 5 + k + k / 4 + j / 4 + 5 * j) % 7;
    return (h + 6) % 7;
}

static void advance_one_second() {
    if (++current_second < 60) return;
    current_second = 0;
    if (++current_minute < 60) return;
    current_minute = 0;
    if (++current_hour < 24) return;
    current_hour = 0;
    if (++current_day <= days_in_month(current_month, current_year)) return;
    current_day = 1;
    if (++current_month <= 12) return;
    current_month = 1;
    current_year++;
}

// API
void time_save_now() {
    clkPrefs.begin("clk", false);
    clkPrefs.putInt("y",  current_year);
    clkPrefs.putInt("mo", current_month);
    clkPrefs.putInt("d",  current_day);
    clkPrefs.putInt("h",  current_hour);
    clkPrefs.putInt("mi", current_minute);
    clkPrefs.putInt("s",  current_second);
    clkPrefs.end();
    save_last = millis();
    Serial.printf("[CLK] Kaydedildi %02d:%02d:%02d %02d.%02d.%04d\n",
                  current_hour, current_minute, current_second,
                  current_day, current_month, current_year);
}

void time_begin() {
    clkPrefs.begin("clk", false);
    current_year   = clkPrefs.getInt("y",  2026);
    current_month  = clkPrefs.getInt("mo", 1);
    current_day    = clkPrefs.getInt("d",  1);
    current_hour   = clkPrefs.getInt("h",  0);
    current_minute = clkPrefs.getInt("mi", 0);
    current_second = clkPrefs.getInt("s",  0);
    clkPrefs.end();

    tick_last = save_last = ntp_last = millis();
    Serial.printf("[CLK] Geri yuklendi %02d:%02d:%02d %02d.%02d.%04d\n",
                  current_hour, current_minute, current_second,
                  current_day, current_month, current_year);
}

void time_set_manual(int h, int mi, int d, int mo, int y) {
    current_hour   = h;
    current_minute = mi;
    current_second = 0;
    current_day    = d;
    current_month  = mo;
    current_year   = y;

    tick_last = millis();
    time_save_now();
}

void time_tick() {
    unsigned long now = millis();

    while (now - tick_last >= 1000UL) {
        tick_last += 1000UL;
        advance_one_second();
    }

    // NTP edited
    if (WiFi.status() == WL_CONNECTED) {
        if (!ntp_configured) {
            configTime(GMT_OFFSET_SEC, 0, "pool.ntp.org", "time.nist.gov");
            ntp_configured = true;
            ntp_last = now - NTP_INTERVAL_MS;  
        }

        if (now - ntp_last >= NTP_INTERVAL_MS) {
            ntp_last = now;
            struct tm ti;
            if (getLocalTime(&ti, 500)) {
                long oldSec = current_hour * 3600L + current_minute * 60L + current_second;

                current_hour   = ti.tm_hour;
                current_minute = ti.tm_min;
                current_second = ti.tm_sec;
                current_day    = ti.tm_mday;
                current_month  = ti.tm_mon + 1;
                current_year   = ti.tm_year + 1900;

                long newSec = current_hour * 3600L + current_minute * 60L + current_second;
                long drift  = newSec - oldSec;

                Serial.printf("[CLK] NTP duzeltme, sapma %ld sn\n", drift);
                if (drift > 2 || drift < -2) time_save_now();
            }
        }
    } else {
        ntp_configured = false;
    }

    if (now - save_last >= SAVE_INTERVAL_MS) time_save_now();
}

TimeData time_get_data() {
    TimeData tData;

    const char* full_days[] = {"Pazar", "Pazartesi", "Sali", "Carsamba",
                               "Persembe", "Cuma", "Cumartesi"};
    tData.day = full_days[weekday_index(current_day, current_month, current_year)];

    char timeBuffer[10];
    sprintf(timeBuffer, "%02d:%02d", current_hour, current_minute);
    tData.fullTime = timeBuffer;

    char dateBuffer[15];
    sprintf(dateBuffer, "%02d.%02d.%d", current_day, current_month, current_year);
    tData.date = dateBuffer;

    return tData;
}