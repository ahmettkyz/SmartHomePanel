#ifndef SENSOR_SERVICE_H
#define SENSOR_SERVICE_H

#include <Arduino.h>

void  sensor_begin();
void  sensor_tick();              // loop() icinde cagir
float sensor_get_temperature();
bool  sensor_is_ok();

#endif