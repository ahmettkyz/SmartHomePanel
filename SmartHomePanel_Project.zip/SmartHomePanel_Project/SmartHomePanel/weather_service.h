#ifndef WEATHER_SERVICE_H
#define WEATHER_SERVICE_H

#include <Arduino.h>
#include <string>

struct WeatherForecast {
    std::string dayName;
    float tempMax;
    float tempMin;
    int weatherCode;
};

struct WeatherData {
    float temperature;
    std::string description;
    WeatherForecast forecast[5];
};

void weather_service_begin();
bool weather_update();
WeatherData weather_get();

#endif